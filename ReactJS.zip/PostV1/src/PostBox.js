import React,{ Component } from "react";
import Post from "./Post";

class PostBox extends Component{
  // method from Component to be overridden

  // exclusive method to manage all posts
  // 1. Hold the repo
  // 2. generate  JSX for it
  _getPosts(){
      const posts = [
          {id : 1, title : "ReactJS", tags : "#frontend", post : "JS Library"},
          {id : 2, title : "Angular", tags : "#frontend", post : "JS Framework"},
          {id : 3, title : "Spring", tags : "#backend", post : "Java Framework"}
      ];
      return posts.map((post) => {
          return (<Post id={post.id} title={post.title} tags={post.tags} post={post.post}/>);
          // return (<Post postdata={post}/>);  
      });
  }

  render(){
    
    // document.getElementById('');
    const postJSX = this._getPosts();
    // must return  UI as JSX
    return(
      <div>
        <h2>Posts...</h2>
        <h4>Posts : {postJSX.length}</h4>
        {postJSX}

        {/* anything to be treated as JS must be written curly braces*/}
        {/*document.getElementById('')*/}
        {/* data required to be sent to another comp need to be passed as attribute */}
        {/* props */}
        {/*  
        <Post title="ReactJS" tags="#frontend" post="JS Library"/>
        <Post title="Angular" tags="#frontend" post="JS Framework"/>
        <Post title="Spring" tags="#backend" post="Java Framework"/>
        */}
      </div>
    );
  }
}

export default PostBox;