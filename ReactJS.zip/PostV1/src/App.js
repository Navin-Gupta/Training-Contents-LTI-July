import React,{ Component } from "react";

class App extends Component{
  // method from Component to be overridden
  render(){
    // must return  UI as JSX
    return(
      <div>
        <h1>Hello All</h1>
        <p className="App-link">Sample Para</p>
      </div>
    );
  }
}

export default App;
