import React,{ Component } from "react";




class PostForm extends Component{

   /* title;
    tags;
    post;*/


 _handleSubmit(event){
    // prevent the default behavior of form
    event.preventDefault();

    // this.title.value;
    // need to call the prop method of parent
    this.props.addpost(this.title.value, this.tags.value, this.post.value);
 }

  render(){
    return(
      <div >
          <hr/>
          <form onSubmit={this._handleSubmit.bind(this)}>
              <label>Join the discussion</label>
              <br/>
              <input type="text" placeholder="Title" ref={(title)=>this.title = title}/>
              <br/>
              <input type="text" placeholder="Tags" ref={(tags)=>this.tags = tags}/>
              <br/>
              <input type="text" placeholder="Post Content" ref={(post)=>this.post = post}/>
              <br/>
              <button type="submit">Add Post</button>
          </form>
          <hr/>
      </div>
    );
  }
}


export default PostForm;