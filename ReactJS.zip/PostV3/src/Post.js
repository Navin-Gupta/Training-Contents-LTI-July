import React,{ Component } from "react";
import './css/Post.css';

class Post extends Component{
  
 /* _customFun(){
    let title = this.props.title;
    this.props.title = "";
  }*/

  render(){
    return(
      <div className="post">
          {/*this.props.postdata.title*/}
        <p><h4>Title : {this.props.title}</h4></p>
        <hr/>
        <p><i>Tags : {this.props.tags}</i></p>
        <p>{this.props.post}</p>
        {/*  Comments */}
      </div>
    );
  }
}

// to create default props
// string, number, boolean, array, object, function
Post.defaultProps = {
  title : "Fullstack",
  proptest : "TestData",
  addPost : function(title, tags, post){}
}

export default Post;