export class Post{
    id : number;
    title : string;
    tags : string;
    post : string;

    constructor(title : string, tags : string, post : string){
        this.title = title;
        this.tags = tags;
        this.post = post;
    }
}