import { Component, OnInit } from '@angular/core';
import { Post } from 'src/app/model/post.model';
import { PostDataService } from 'src/app/service/data/post-data.service';


@Component({
  selector: 'app-post',
  templateUrl: './post.component.html',
  styleUrls: ['./post.component.css']
})
export class PostComponent implements OnInit {

  posts : Post[];
  message : string;

  // add dependency of data service
  constructor(private dataService : PostDataService) { 
    this.message = "Your posts here..."
    // initiate with dummy posts
    /*this.posts = [
      new Post("Learning", "#frontend,#angular", "Learning Angular Now!!"),
      new Post("Training", "#frontend,#angular", "Training for Full-Stack!!")
    ];*/
  }

  addPostData(post:Post){
    // send object to server as well
    this.dataService.addNewPost(post).subscribe(
      // return a newly added record from DB
      // add it to collection
      (response : Post)=> {
        console.log("Received Data");
        this.posts.push(response);
      }
    );
    console.log("Called Server...");
  }
  
  // one of earliest phases of component lifecycle
  ngOnInit() {
    // resource management
    // http service returns an Observable (Future)
    // http service is non-blocking(reactive/async) : need to subscribe (provide callback method)
    this.dataService.getAllPosts().subscribe(
      (response:Post[]) => this.posts = response , // success
      (error:any) => console.log(error) // failed
    );
  }

}
