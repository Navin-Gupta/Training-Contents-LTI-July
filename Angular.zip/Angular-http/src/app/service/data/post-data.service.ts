import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Post } from 'src/app/model/post.model';
import { Observable } from 'rxjs';

const API_URL = "http://localhost:3000/post";

@Injectable({
  providedIn: 'root'
})
export class PostDataService {

  constructor(private http:HttpClient) { }

  // get all posts from server
  getAllPosts():Observable<Object>{ //Observable<Post[]>
    return this.http.get(API_URL); // Observable
  }

  // add a new post
  addNewPost(post: Post){
    // request will initiated only when there is a subscription
    return this.http.post(API_URL, post);
  }

}
