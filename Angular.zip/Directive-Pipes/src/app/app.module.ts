import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { PipeCheckComponent } from './pipe-check/pipe-check.component';
import { SizePipe } from './custom-pipe/size.pipe';

@NgModule({
  // array of all components inside the current module
  declarations: [
    AppComponent,
    PipeCheckComponent,
    SizePipe
  ],
  // allows to integrate other modules with your
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  // inject specific dependency (for all child components)
  providers: [],
  // under the current module, which component(s) can be used as bootstrap
  bootstrap: [AppComponent]
})
export class AppModule { }
