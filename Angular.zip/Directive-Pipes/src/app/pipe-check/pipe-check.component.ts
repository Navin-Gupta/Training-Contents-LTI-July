import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pipe-check',
  templateUrl: './pipe-check.component.html',
  styleUrls: ['./pipe-check.component.css']
})
export class PipeCheckComponent implements OnInit {

  name : string;
  rate : number;
  gpa : number;
  hobbies : string[];
  profile : Object;
  dob : Date;
  fileSize : number;

  constructor() { 
    this.name = "First";
    this.rate = 100;
    this.gpa = 1234.56789;
    this.hobbies = ["Football","Reading","Chess","Basketball"];
    this.profile = {
      "email" : "first@mail.com",
      "address" : {
        "lane" : 6,
        "location" : "Some Area",
        "city" : "Delhi"
      }
    };
    this.dob = new Date();
    this.fileSize = 54657634;

  }

  ngOnInit() {
  }

}
