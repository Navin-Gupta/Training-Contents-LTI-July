import { SizePipe } from './size.pipe';

describe('SizePipe', () => {
  it('create an instance', () => {
    const pipe = new SizePipe();
    expect(pipe).toBeTruthy();
  });
});
