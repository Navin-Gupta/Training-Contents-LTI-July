import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'size',
  pure : true
})
export class SizePipe implements PipeTransform {

  state : string;
  // transform(originalValue: number, type1:string="MB", type2:string): string {
  transform(originalValue: number, type:string="MB"): string {
    let response = "";
    switch(type){
      case "MB" : response = (originalValue/(1024*1024)).toFixed(2) + " MB"; break;
      case "KB" : response = (originalValue/(1024)).toFixed(2) + " KB"; break;
      default : response = originalValue + " byte";
    }
    return response;
  }

}
