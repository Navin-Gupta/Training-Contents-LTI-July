import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {

  searchData : string;
  // to receive the coming through navigation (path variable)
  // service/object exposed by RoutingModule
  constructor(activateRoute : ActivatedRoute) { 
    // recieve data from navigation url
    // activateRoute is by default reactive in nature (non-blocking)
    // need to subscribe and pass a callback
    // activatedRoute allows to access info about navigation
    activateRoute.params.subscribe(
      (params)=> this.searchData = params['srch']);
  }

  ngOnInit() {
  }

}
