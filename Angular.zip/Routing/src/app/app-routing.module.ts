import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './common/home/home.component';
import { AboutComponent } from './common/about/about.component';
import { ContactComponent } from './common/contact/contact.component';
import { PostComponent } from './postresources/post/post.component';
import { SearchComponent } from './common/search/search.component';

// way to navigate to a component using url
// Maps a URL with component : Route object
// an array (Collection) of Route Object
const routes: Routes = [
  // route Object
  {path:"home", component : HomeComponent},
  {path:"about-us", component : AboutComponent},
  {path:"contact-us", component : ContactComponent},
  {path:"post", component : PostComponent},

  // /:srch : Path Variable
  {path:"search/:srch", component: SearchComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
