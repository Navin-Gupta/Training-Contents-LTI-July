import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  // custom tag of component
  selector: 'app-root',
  // template : `<h1>Hello from Component</h1>`,
  // view file
  templateUrl: './app.component.html',
  // array of multiple css files
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  
  // RouterModule exposes service/object : Router(inject as dependency)
  constructor(private router:Router){
    
  }

  searchCall(txtSearch : HTMLInputElement){
    // to navigate programmatically, need service from RoutingModule
    let text = txtSearch.value;
    if(text != ""){
      this.router.navigate(['/search/' + text]);
    }
  }
}
// /search/Angular