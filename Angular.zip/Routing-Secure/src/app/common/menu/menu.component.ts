import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from 'src/app/service/authentication.service';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})
export class MenuComponent implements OnInit {

  // need to inject dependency of Authentication Servcie
  // controlling menu presentation
  constructor(public auth : AuthenticationService) { }

  ngOnInit() {
  }

}
