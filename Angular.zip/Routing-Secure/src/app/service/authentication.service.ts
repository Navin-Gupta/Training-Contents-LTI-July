import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  // method to check the credential
  authenticate(loginid : string, password : string): boolean{
    // hard coded check
    if(loginid === "First" && password === "abc"){
      // need to maintain state : sessionStorage
      // allows to store user data as key value pair
      sessionStorage.setItem("user",loginid); 
      return true;
    }else{
      return false;
    }
  }

  // to check if user is logged in
  isUserLoggedIn(): boolean{
    let user = sessionStorage.getItem("user");
    if(user == null){
      return false;
    }else{
      return true;
    }
  }

  // getUSerType
  // getUSerNAme
  // getUserDEtail

  // logout 
  logout(){
    sessionStorage.removeItem("user");
    sessionStorage.clear()
  }  
}










