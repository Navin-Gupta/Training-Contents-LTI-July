import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { AuthenticationService } from './authentication.service';

@Injectable({
  providedIn: 'root'
})
export class AuthGuardService implements CanActivate{

  constructor(private auth:AuthenticationService,
              private router : Router) { }
  
  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean | import("@angular/router").UrlTree | import("rxjs").Observable<boolean | import("@angular/router").UrlTree> | Promise<boolean | import("@angular/router").UrlTree> {
    // route.url
    // guard logic
    // if authenticated user , allow the access 
    // else navigate to login component
    if(this.auth.isUserLoggedIn()){
      return true;
    }else{
      // navigate to login component
      this.router.navigate(['/login']);
      return false;
    }
  }
}
