import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from 'src/app/service/authentication.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  errorMessage : string;
  autherized : boolean;
  // need to DI for authentication Service
  constructor(private auth : AuthenticationService, 
              private router : Router) { 
      this.errorMessage = " Invalid Credentials!!!";
      this.autherized = true;
  }

  validate(txtLogin : HTMLInputElement, txtPass : HTMLInputElement){
    // need to take use of authentication service
    if(this.auth.authenticate(txtLogin.value, txtPass.value)){
        // navigate to secured resource
        this.autherized = true;
        this.router.navigate(['/post']);

    }else{
      this.autherized = false;
    }
  }

  ngOnInit() {
  }

}
