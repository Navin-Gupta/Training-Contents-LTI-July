import { Component } from '@angular/core';

@Component({
  // custom tag of component
  selector: 'app-root',
  // template : `<h1>Hello from Component</h1>`,
  // view file
  templateUrl: './app.component.html',
  // array of multiple css files
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'ang-app';
}
