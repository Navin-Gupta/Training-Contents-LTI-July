import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';


import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsTemplateComponent } from './forms/forms-template/forms-template.component';
import { FormsReactiveComponent } from './forms/forms-reactive/forms-reactive.component';

@NgModule({
  // array of all components inside the current module
  declarations: [
    AppComponent,
    FormsTemplateComponent,
    FormsReactiveComponent
  ],
  // allows to integrate other modules with your
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule
  ],
  // inject specific dependency (for all child components)
  providers: [],
  // under the current module, which component(s) can be used as bootstrap
  bootstrap: [AppComponent]
})
export class AppModule { }
