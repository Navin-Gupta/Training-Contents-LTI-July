import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-forms-reactive',
  templateUrl: './forms-reactive.component.html',
  styleUrls: ['./forms-reactive.component.css']
})
export class FormsReactiveComponent implements OnInit {

  name : string;
  category : string;
  cost : number;

  // variables for virtual Form
  productFormGroup : FormGroup;
  // productName : FormControl = new FormControl();
  productName : FormControl;
  // productCategory : FormControl;
  // productCost : FormControl;


  // When we add ReactiveFormsModule as import
  // multiple precreated object will be exposed, that can be injected
  // Constructer based DI
  // eg : FormBuilder
  constructor(formBuilder : FormBuilder) { 
    // initiate the form Control
    this.productName = new FormControl("",Validators.required);
    // this.productCategory = new FormControl();
    // this.productCost = new FormControl();
    this.category = "Books";
    // create the composition of Form Controls
    /*this.productFormGroup = formBuilder.group(
      {
        "product_name" : this.productName,
        "product_cat" : this.productCategory,
        "product_cost" : this.productCost
      }
    );*/
    this.productFormGroup = formBuilder.group(
      {
        "product_name" : this.productName,
        // "product_cat" : new FormControl("Electronics", Validators.required),
        "product_cat" : new FormControl(this.category, Validators.compose(
                                                        [Validators.required,
                                                         Validators.minLength(5)]
                                                        )),
        "product_cost" : new FormControl("", Validators.compose([
            Validators.required , this.rangeCheck
        ]))
      }
    );
  }

  // custom validation
  // manadatory param : FormControl
  // in case of Invalidity : return an object : single field
  // rangeCheck(cost : FormControl,min : number , max : number){
  rangeCheck(cost : FormControl){
    if(parseInt(cost.value) < 100 || parseInt(cost.value) > 1000){
      return {
        // <constraint name> : <boolean>
        // return true if constrant fails
        "range" : true
      };
    }
  }
 
  saveProduct(){
    this.name = this.productName.value;
    this.category = this.productFormGroup.controls['product_cat'].value;
    this.cost = this.productFormGroup.controls['product_cost'].value;
    // this.productFormGroup.controls['product_cat'].hasError('maxlength')
    alert("Product Added Successfully")
  }

  ngOnInit() {
  }

}
