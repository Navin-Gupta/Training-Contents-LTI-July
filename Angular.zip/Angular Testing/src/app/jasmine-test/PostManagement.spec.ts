import { PostManagement } from "./PostManagement";

describe("Testing Post Management", ()=>{
   
    let post : PostManagement;

    beforeAll(()=>{
        post = new PostManagement();
    });

    beforeEach(()=>{
        post.totalLikes = 2;
    });
   
    it("should increment totalLikes",()=>{
       
        
        // ACT
        post.like();

        // ASSERT
        expect(post.totalLikes).toBe(3);
    });

    it("should decrement totalLikes",()=>{
                
        // ACT
        post.dislike();

        // ASSERT
        expect(post.totalLikes).toBe(1);
    });

    it("should decrement totalLikes only of totalLikes is greater than 0",()=>{
        // ARRANGE        
        post.totalLikes = 0;
        // ACT
        post.dislike();

        // ASSERT
        expect(post.totalLikes).not.toBe(-1);
    });

});