// Test suite : describe
// describe(<string : informative text>, <function>);

// describe("Dummy Test", function(){});

describe("Dummy Test", ()=>{

    // execute once before any "it"
    beforeAll(()=>{})

    // going to execute before each "it" in "describe"
    beforeEach(()=>{})

    // we dont write test cases directly inside it
    // each test case : it(<string : informative text>, <function>);
    it("Test 1",()=>{
        // expect(<actual>).toEqual(<expected>)
        expect(1+1).toEqual(2);
    });
    it("Test 2",()=>{
        // expect(<actual>).toEqual(<expected>)
        expect(1-1).toEqual(0);
    });

    // execute after every "it"
    afterEach(()=>{})

    // execute once after all "it"
    afterAll(()=>{})
});
