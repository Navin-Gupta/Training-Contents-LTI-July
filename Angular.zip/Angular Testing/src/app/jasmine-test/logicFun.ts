export function greet(name : string){
    return "Hi " + name + "!";
}