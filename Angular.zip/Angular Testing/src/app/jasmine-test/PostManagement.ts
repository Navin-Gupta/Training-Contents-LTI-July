export class PostManagement{
    totalLikes : number;

    like(){
        this.totalLikes++;
    }

    dislike(){
        if(this.totalLikes > 0)
            this.totalLikes--;
    }
}