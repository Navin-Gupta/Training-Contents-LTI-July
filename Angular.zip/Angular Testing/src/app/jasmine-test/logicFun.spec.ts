import { greet } from "./logicFun";


describe("Testing Function", ()=>{
    it("Testing greet function", ()=>{
        // ARRANGE
        const expected = "Hi First";
        
        // ACT
        const result =  greet("First");

        // ASSERT    
        // expect(result).toEqual(expected); // fragile
        expect(result).toContain(expected);
    });
});