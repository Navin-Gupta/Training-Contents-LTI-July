import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductComponent } from './product.component';
import { ProductService } from '../product.service';
import { Product } from '../model/Product';

describe('ProductComponent', () => {
 
  let component : ProductComponent;
  let service : ProductService;

  beforeEach(()=>{
    // service = new ProductService(null); // if http service
    service = new ProductService();
    // explicitly inject
    component = new ProductComponent(service);
  });

  it("should get the products from service and apply some logic", ()=>{
    // ARRANGE
    const fakeProducts : Product[] = [
      new Product("Dummy1", "DummyCat1", 100),
      new Product("Dummy2", "DummyCat2", 200)
    ];

    let spy = spyOn(service, "getProducts").and.callFake(()=>{
      // logic 
      return fakeProducts;
    });
    // spyOn(service, "getProducts").and.returnValue(fakeProducts);
    // Act 
    component.initProducts();

    // Assert
    expect(component.products).toEqual(fakeProducts);
    expect(spy).toHaveBeenCalled();
  });

  
});
