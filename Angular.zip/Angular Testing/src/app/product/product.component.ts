import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';
import { Product } from '../model/Product';
import { Server } from 'http';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent  {

  products : Product[];
  constructor(public service : ProductService) { }

  initProducts(){
    // logic
    this.products = this.service.getProducts();
    // logic
  }
 

}
