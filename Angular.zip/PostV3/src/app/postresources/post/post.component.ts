import { Component, OnInit } from '@angular/core';
import { Post } from 'src/app/model/post.model';

@Component({
  selector: 'app-post',
  templateUrl: './post.component.html',
  styleUrls: ['./post.component.css']
})
export class PostComponent implements OnInit {

  posts : Post[];
  message : string;

  constructor() { 
    this.message = "Your posts here..."
    // initiate with dummy posts
    this.posts = [
      new Post("Learning", "#frontend,#angular", "Learning Angular Now!!"),
      new Post("Training", "#frontend,#angular", "Training for Full-Stack!!")
    ];
  }

  addPostData(post:Post){
    // add it to collection
    this.posts.push(post);
  }
  

  ngOnInit() {
  }

}
